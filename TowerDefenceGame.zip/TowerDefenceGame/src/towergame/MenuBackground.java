package towergame;

import jgame.GSprite;
import jgame.ImageCache;

public class MenuBackground extends GSprite {
	public MenuBackground() {
		super(ImageCache.getImage("bg.jpg"));
	}
}
