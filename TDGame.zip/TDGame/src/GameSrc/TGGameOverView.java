package GameSrc;

import jgame.GContainer;

public class TGGameOverView extends GContainer {

}
